import java.util.ArrayList;
import java.util.List;

public class Phonebook {
    private ArrayList<Contact> contacts;

    public Phonebook() {
        contacts = new ArrayList<>();
    }

    // 1. Insert Contact
    public void insertContact(String name, String phoneNumber) {
        Contact newContact = new Contact(name, phoneNumber);
        contacts.add(newContact);
    }

    // 2. Search Contact
    public Contact searchContact(String name) {
        for (Contact contact : contacts) {
            if (contact.getName().equalsIgnoreCase(name)) {
                return contact;
            }
        }
        return null;
    }

    // 3. Display All Contacts
    public String displayAllContacts() {
        if (contacts.isEmpty()) {
            return "No contacts found.";
        } else {
            StringBuilder allContacts = new StringBuilder();
            for (Contact contact : contacts) {
                allContacts.append(contact).append("\n");
            }
            return allContacts.toString();
        }
    }

    // 4. Delete Contact
    public boolean deleteContact(String name) {
        Contact contact = searchContact(name);
        if (contact != null) {
            contacts.remove(contact);
            return true;
        }
        return false;
    }

    // 5. Update Contact
    public boolean updateContact(String name, String newPhoneNumber) {
        Contact contact = searchContact(name);
        if (contact != null) {
            contact.setPhoneNumber(newPhoneNumber);
            return true;
        }
        return false;
    }
}
