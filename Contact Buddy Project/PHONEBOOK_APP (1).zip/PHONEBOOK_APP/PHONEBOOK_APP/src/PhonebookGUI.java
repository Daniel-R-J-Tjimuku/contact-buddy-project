import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class PhonebookGUI extends JFrame {
    private Phonebook phonebook;
    private JTextField nameField, phoneField, searchField, updateField;
    private JTextArea displayArea;
    
    public PhonebookGUI() {
        phonebook = new Phonebook();

        // Setting up the main frame
        setTitle("Phonebook Application");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create components for the GUI
        nameField = new JTextField(15);
        phoneField = new JTextField(15);
        searchField = new JTextField(15);
        updateField = new JTextField(15);
        displayArea = new JTextArea(15, 40);
        displayArea.setEditable(false);

        // Adding buttons
        JButton insertButton = new JButton("Insert Contact");
        JButton searchButton = new JButton("Search Contact");
        JButton displayButton = new JButton("Display All Contacts");
        JButton deleteButton = new JButton("Delete Contact");
        JButton updateButton = new JButton("Update Contact");

        // Adding listeners to buttons
        insertButton.addActionListener(new InsertButtonListener());
        searchButton.addActionListener(new SearchButtonListener());
        displayButton.addActionListener(new DisplayButtonListener());
        deleteButton.addActionListener(new DeleteButtonListener());
        updateButton.addActionListener(new UpdateButtonListener());

        // Creating a panel for adding contacts
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2));
        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Phone Number:"));
        inputPanel.add(phoneField);
        inputPanel.add(insertButton);
        inputPanel.add(displayButton);

        // Creating a panel for searching, deleting, and updating contacts
        JPanel actionPanel = new JPanel();
        actionPanel.setLayout(new GridLayout(3, 2));
        actionPanel.add(new JLabel("Search/Delete Contact by Name:"));
        actionPanel.add(searchField);
        actionPanel.add(searchButton);
        actionPanel.add(deleteButton);
        actionPanel.add(new JLabel("Update Contact with New Phone Number:"));
        actionPanel.add(updateField);
        actionPanel.add(updateButton);

        // Scroll pane for displaying contacts
        JScrollPane scrollPane = new JScrollPane(displayArea);

        // Adding panels and components to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(actionPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    // Action listeners for buttons
    private class InsertButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String name = nameField.getText();
            String phoneNumber = phoneField.getText();

            if (!name.isEmpty() && !phoneNumber.isEmpty()) {
                phonebook.insertContact(name, phoneNumber);
                displayArea.setText("Contact inserted: " + name + " - " + phoneNumber);
                nameField.setText("");
                phoneField.setText("");
            } else {
                displayArea.setText("Please fill in both fields.");
            }
        }
    }

    private class SearchButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String name = searchField.getText();
            Contact contact = phonebook.searchContact(name);
            if (contact != null) {
                displayArea.setText("Contact found: " + contact);
            } else {
                displayArea.setText("Contact not found.");
            }
        }
    }

    private class DisplayButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            displayArea.setText("All Contacts:\n" + phonebook.displayAllContacts());
        }
    }

    private class DeleteButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String name = searchField.getText();
            if (phonebook.deleteContact(name)) {
                displayArea.setText("Contact deleted: " + name);
            } else {
                displayArea.setText("Contact not found.");
            }
        }
    }

    private class UpdateButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String name = searchField.getText();
            String newPhoneNumber = updateField.getText();

            if (phonebook.updateContact(name, newPhoneNumber)) {
                displayArea.setText("Contact updated: " + name + " - " + newPhoneNumber);
            } else {
                displayArea.setText("Contact not found.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PhonebookGUI gui = new PhonebookGUI();
            gui.setVisible(true);
        });
    }
}

